#!/usr/bin/env python3
"""
build.py — run this once to produce dist/server.exe
Requires: pip install pyinstaller flask
"""
import subprocess
import sys
import os

def main():
    print("Installing dependencies...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "flask", "pyinstaller", "--quiet"])

    print("Building exe...")
    subprocess.check_call([
        "pyinstaller",
        "--onefile",            # single .exe
        "--noconsole",          # no terminal window (remove if you want logs visible)
        "--name", "local-dev-server",
        "server.py",
    ])

    exe = os.path.join("dist", "local-dev-server.exe")
    if os.path.exists(exe):
        size_mb = os.path.getsize(exe) / 1024 / 1024
        print(f"\n✓ Done → {exe}  ({size_mb:.1f} MB)")
        print("  Double-click it. Browser opens automatically.")
    else:
        print(f"\n✓ Done → dist/local-dev-server  (Linux/Mac build)")

if __name__ == "__main__":
    main()
